/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.io;

import elevationprofiler.FormatType;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;

/**
 *
 * @author ms6401
 */
public class ConfigurationManager {

    ///config file location
    File config_file = new File("config_file.xml");
    
    ///current directory position
    public String current_directory = ".";
    
    ///dted data location
    public String dted_root_location = null;
    
    //output format type
    public FormatType format_type = FormatType.MATLAB;

    /**
     * Load the config file and read values
     */
    void loadConfiguration() {

        //check for the configuration file
        if (config_file.exists() == true) {

            try {

                //create the document builder factory
                DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
                Document document = docBuilder.parse(config_file);
                
                
            
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }




    }

    void saveConfiguration() {
    
    
    
    }
}


/*
            NodeList nodes = document.getDocumentElement().getChildNodes();

            for (int i = 0; i < nodes.getLength(); i++) {

                Node node = nodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE && ((Element) node).getTagName().equals("Document")) {

                    Element docElement = (Element) node;

                    NodeList placemarkList = docElement.getElementsByTagName("Placemark");

                    NodeList lineSet = ((Element) placemarkList.item(0)).getElementsByTagName("coordinates");

                    String content = lineSet.item(0).getTextContent().trim();
                    String[] items = content.split("\\s+|,");

                    if (items.length % 3 != 0) {
                        throw new Exception("ERROR: kml must have strings with 3 values per coordinate");
                    }



                    for (int it = 0; it < items.length / 3; it++) {
                        coordinateList.add(new GeodeticDD(Double.valueOf(items[it * 3 + 0]),
                                Double.valueOf(items[it * 3 + 1])));
                    }

                }
            }

        } catch (SAXException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } 

        return coordinateList;

    }
    */
