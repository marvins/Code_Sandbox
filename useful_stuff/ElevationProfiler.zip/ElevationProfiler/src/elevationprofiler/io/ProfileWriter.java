/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.io;

import elevationprofiler.FormatType;
import elevationprofiler.geographic.GeoTuple;
import elevationprofiler.geographic.RouteContainer;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author ms6401
 */
public class ProfileWriter {

    public int max_point_gap;

    public void write_profile(RouteContainer routeData, ConfigurationManager options, JFrame comp ) {

        try {
            //we have the route data, but we need the list of intermediate steps and their values
            ArrayList<GeoTuple> elevation_profile_data = routeData.computeProfile(max_point_gap, options);
            ArrayList<GeoTuple> original_profile_data = routeData.computeProfile(0, options);

            KMLParser.writeKMLFile("output.kml", elevation_profile_data);
            KMLParser.writeKMLFile("input.kml", original_profile_data);

            // check if output format type is MATLAB
            if (options.format_type == FormatType.MATLAB) {
                MatlabParser.buildMatlabPlotter(elevation_profile_data);
            } // check if output format type is PYTHON
            else if (options.format_type == FormatType.PYTHON) {
                SciPyParser.buildSciPyPlotter(elevation_profile_data);
            }
        } catch (FileNotFoundException ex) {
            
            //since the operation failed, we need to open a dialog
            JOptionPane.showMessageDialog( comp, "Chosen DTED Directory is Invalid.");
        }

    }

    public void set_max_gap(int max_gap) {
        max_point_gap = max_gap;
    }
}
