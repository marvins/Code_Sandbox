/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.io;

import elevationprofiler.geographic.GeoTuple;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author ms6401
 */
public class SciPyParser {

    public static void buildSciPyPlotter(ArrayList<GeoTuple> coordinateList) {


        //Write contents to file
        try {
            Charset charset = Charset.forName("US-ASCII");


            Path target = Paths.get("output.py");
            
            Path file = null;
            try{
                file = Files.createFile(target);
            } catch( FileAlreadyExistsException e ){
                Files.delete(target);
                file = Files.createFile(target);
            }

            //create the buffered writer
            BufferedWriter writer = Files.newBufferedWriter(file, charset);
            
            //print the run command
            writer.write("#! /usr/bin/env python\n");

             //add the required libraries
            writer.write("import matplotlib.pyplot as plt\n");
            writer.write("\nfrom numpy import *\n\n");
            
            //create the y axis
            writer.write("Y_data = array([");
            
            for( int i=0; i<coordinateList.size()-1; i++ ){
                writer.write( coordinateList.get(i).elevationMeters + ", ");
            }
            writer.write( coordinateList.get(coordinateList.size()-1).elevationMeters + "])\n");
            
            //create the x axis
            writer.write("X_data = array([");
            
            for( int i=0; i<coordinateList.size()-1; i++ ){
                writer.write( coordinateList.get(i).distanceStart + ", ");
            }
            
            writer.write( coordinateList.get(coordinateList.size()-1).distanceStart + "])\n");
            
            
            //create the plot command
            writer.write("plt.plot(X_data, Y_data, '-xg')");
            writer.write("plt.show()");
            writer.close();

        } catch (IOException x) {
            System.err.format("IOException: %s%n", x);


        }
    }
}
