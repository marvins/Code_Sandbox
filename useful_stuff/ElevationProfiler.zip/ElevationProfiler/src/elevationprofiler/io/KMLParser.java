/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.io;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import elevationprofiler.geographic.GeoTuple;
import elevationprofiler.geographic.GeodeticDD;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilderFactory;

/**
 *
 * @author ms6401
 */
public class KMLParser {

    public ArrayList<GeodeticDD> openKMLFile(String kml_filename) {

        //TODO:  Do some checking for right file type, etc
        ArrayList<GeodeticDD> coordinateList;
        coordinateList = new ArrayList<>();
        try {

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();

            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

            Document document = docBuilder.parse(kml_filename);


            NodeList nodes = document.getDocumentElement().getChildNodes();

            for (int i = 0; i < nodes.getLength(); i++) {

                Node node = nodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE && ((Element) node).getTagName().equals("Document")) {

                    Element docElement = (Element) node;

                    NodeList placemarkList = docElement.getElementsByTagName("Placemark");

                    NodeList lineSet = ((Element) placemarkList.item(0)).getElementsByTagName("coordinates");

                    String content = lineSet.item(0).getTextContent().trim();
                    String[] items = content.split("\\s+|,");

                    if (items.length % 3 != 0) {
                        throw new Exception("ERROR: kml must have strings with 3 values per coordinate");
                    }



                    for (int it = 0; it < items.length / 3; it++) {
                        coordinateList.add(new GeodeticDD(Double.valueOf(items[it * 3 + 0]),
                                Double.valueOf(items[it * 3 + 1])));
                    }

                }
            }

        } catch (SAXException e) {
            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return coordinateList;

    }

    public static void writeKMLFile(String filename, ArrayList<GeoTuple> coordinates) {

        try {

            System.out.println("Start of writeKMLFile");
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            Document doc = docBuilder.newDocument();

            Element kmlElement = doc.createElement("kml");
            
            Element docElement  = doc.createElement("Document");
            
            Element nameElement = doc.createElement("name");
            nameElement.appendChild(doc.createTextNode(filename));
                    
            Element placeElement = doc.createElement("Placemark");
            Element pnameElement = doc.createElement("name");
            pnameElement.appendChild(doc.createTextNode("RoadPath"));
            
            Element lineElement = doc.createElement("LineString");
            
            Element tessellateElement = doc.createElement("tessellate");
            tessellateElement.appendChild(doc.createTextNode("1"));
            
            Element coordinateElement = doc.createElement("coordinates");
            coordinateElement.appendChild(doc.createTextNode(createCoordinateLineOutput(coordinates)));
            
                 
            
            lineElement.appendChild(coordinateElement);
            lineElement.appendChild(tessellateElement);
            
            
            
            placeElement.appendChild(lineElement);
            placeElement.appendChild(pnameElement);
            
            doc.appendChild(kmlElement);
            
            kmlElement.appendChild(docElement);
            docElement.appendChild(nameElement);
            docElement.appendChild(placeElement);
            
            
            Element pointElement;
            for( GeoTuple coord : coordinates ){
                placeElement = doc.createElement("Placemark");
                pointElement = doc.createElement("Point");
                coordinateElement = doc.createElement("coordinates");
                coordinateElement.appendChild(doc.createTextNode(coord.toKMLString()));
                pointElement.appendChild(coordinateElement);
                placeElement.appendChild(pointElement);
                docElement.appendChild(placeElement);
                
            }
            
            
            //write content to file
            OutputFormat format = new OutputFormat(doc);
            format.setIndenting(true);
            
            XMLSerializer serializer = new XMLSerializer( new FileOutputStream( new File(filename)), format);
            serializer.serialize(doc);
            
            System.out.println("\n Saved");
            
        } catch (ParserConfigurationException | IOException pce) {
            pce.printStackTrace();
        }

    }
    
    
    public static String createCoordinateLineOutput( ArrayList<GeoTuple> data ){
        
        String output = "\n";
        for( GeoTuple coord : data ){
            
            output += coord.toKMLString() + "\n ";
        }
        return output;
    }
}
