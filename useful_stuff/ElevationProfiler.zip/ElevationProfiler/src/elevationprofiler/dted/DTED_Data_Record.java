/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

/*
 *
 * CLASSIFICATION:       UNCLASSIFIED
 *
 *  CSCI:                DTED file processor
 *
 *  HISTORY:
 *
 *   Date      PTR#      Name     Description and Procedures
 *   MM/DD/YY  ######    Inits
 *   --------  --------  -----    ---------------------------
 *   07/01/11  004994    TD       Creation
 *
 */
import java.nio.ByteBuffer;
/*
 * DTED Data Record Segment
 */
class DTED_Data_Record {
    
    // Class variables
    private byte DATA_SENTINEL = -86;
    public byte m_Sentinel;
    public byte[] m_DataBlockCountRaw = new byte[3];
    public double m_Longitude;
    public double m_Latitude;
    public double m_LongitudeOfOriginDeg;
    public double m_LatitudeOfOriginDeg;
    public short m_LongitudeCount;
    public short m_LattitudeCount;
    public int m_LongitudeProfileCount;
    public int m_LatitudeCountPerLongitudeLine;
    public short[][] m_ElevationPoint;
    private double m_LongitudeIntervalDeg;
    private double m_LatitudeIntervalDeg;
    public double m_CellMaxLongitudeValue;
    public double m_CellMinLongitudeValue;
    private double m_Cell75PercentLongitudeValue;
    private double m_Cell50PercentLongitudeValue;
    private double m_Cell25PercentLongitudeValue;
    public double m_CellMaxLatitudeValue;
    public double m_CellMinLatitudeValue;
    private double m_Cell50PercentLatitudeValue;
    private double m_Cell75PercentLatitudeValue;
    private double m_Cell25PercentLatitudeValue;
    //public int m_CheckSum;
    /*
     * Constructor
     */
    public DTED_Data_Record(ByteBuffer buff) {
        m_Sentinel = buff.get(0);
        m_DataBlockCountRaw[0] = buff.get(1);
        m_DataBlockCountRaw[1] = buff.get(2);
        m_DataBlockCountRaw[2] = buff.get(3);
        m_LongitudeCount = buff.getShort(4);
        m_LattitudeCount = buff.getShort(6);
        m_ElevationPoint = null;
        m_Longitude = -1.0d;
        m_Latitude = -1.0d;
        
    }
    /*
     * Set Latitude in Deg
     */
    public void setLatitudeDeg(double deg) {
        m_Latitude = deg;
    }
    /*
     * Set Longitude in Deg
     */
    public void setLongitudeDeg(double deg) {
        m_Longitude = deg;
    }
    /*
     * Set Longitude of Origin in Deg
     */
    public void setLongitudeOfOriginDeg(double deg) {
        m_LongitudeOfOriginDeg = deg;
    }
    /*
     * set Latitude of Origin in Deg
     */
    public void setLatitudeOfOriginDeg(double deg) {
        m_LatitudeOfOriginDeg = deg;
    }
    /*
     * Set Lattitude Count Per Longitude Line
     */
    public void setLatitudeCountPerLongitudeLine(int count) {
        m_LatitudeCountPerLongitudeLine = count;
    }
    /*
     * Get Latitude Count Per Longitude Line
     */
    public int getLatitudeCountPerLongitudeLine() {
        return m_LatitudeCountPerLongitudeLine;
    }
    /*
     * Set Longitude Profile Count
     */
    public void setLongitudeProfileCount(int count) {
        m_LongitudeProfileCount = count;
    }
    /*
     * get Longitude Profile Count
     */
    public int getLongitudeProfileCount() {
        return m_LongitudeProfileCount;
    }
    /*
     * Set Longitude Interval in Deg
     */
    public void setLongitudeIntervalDeg(double deg) {
        m_LongitudeIntervalDeg = deg;
    }
    /*
     * Get Longitude Interval in Deg
     */
    public double getLongitudeIntervalDeg() {
        return m_LongitudeIntervalDeg;
    }
    /*
     * Set Latitude Interval Deg
     */
    public void setLatitudeIntervalDeg(double deg) {
        m_LatitudeIntervalDeg = deg;
    }
    /*
     * Get Latitude Interval Deg
     */
    public double getLatitudeIntervalDeg() {
        return m_LatitudeIntervalDeg;
    }
    
    
    /**
     * Pull the pixel elevation value directly from the buffer
     * @param buff  Open and valid buffer object
     * @param lonIdx index of longitude coordinate
     * @param latIdx index of latitude coordinate
     * @return Elevation in meters
     */
    public double getElevationPoint(ByteBuffer buff, int lonIdx, int latIdx ) {
        
        //make sure that the indices provided are useable
        if( lonIdx < 0 )
            throw new IllegalArgumentException("lonIdx of " + lonIdx + " is less than 0");
        if( lonIdx >= m_LongitudeProfileCount )
            throw new IllegalArgumentException("lonIdx of " + lonIdx + " is >= than LongitudeProfileCount which is " + m_LongitudeProfileCount);
        if( latIdx < 0 )
            throw new IllegalArgumentException("latIdx of " + latIdx + " is less than 0");
        if( latIdx >= m_LatitudeCountPerLongitudeLine )
            throw new IllegalArgumentException("latIdx of " + latIdx + " is >= than LatitudeCountPerLongitudeLine which is " + m_LatitudeCountPerLongitudeLine );
        
        //make sure that we have an elevation profile which is valid
        if (m_LongitudeProfileCount > 0 && m_LatitudeCountPerLongitudeLine > 0) {
            
            //make sure the Data Sentinel Tags Match
            if (m_Sentinel == DATA_SENTINEL) {
                
                int bufferIndex = 2 * latIdx + ( lonIdx * (( 2 * m_LatitudeCountPerLongitudeLine) + 12 )) + 8;
                
                //return the buffer position
                double value =  buff.getShort(bufferIndex);
                if( value < 0 )
                    value = (-1*value) - 32768;//remember 1's compliment
                return value;
            }
            else
                throw new IllegalArgumentException("Error: Sentinel Tags do not match");
        } else{
            throw new IllegalArgumentException("Error: CongitudeProfileCount = 0 or LatitudeCountPerLongitudeLine = 0");
        }
        
    }
    
    
    /*
     * Get Elevation From Long Lat in Meter
     */
    public short getElevationFromLongLatInMeter(int elevLongIndex, int elevLatIndex) {
        short elevationInMeter = 0;

        
        //System.out.println("getElevationFromLongLatInMeter, elevLongIndex: " + elevLongIndex + ", elevLatIndex: " + elevLatIndex);
        if (elevLongIndex > -1 && elevLatIndex > -1 && m_ElevationPoint != null) {
            elevationInMeter = m_ElevationPoint[elevLongIndex][elevLatIndex];
            if (elevationInMeter < 0) {
            //    elevationInMeter = 0;
            }
            //System.out.println("Terrian elevationInMeter: " + elevationInMeter + " METERS");
        }
        return elevationInMeter;
    }
    
    
    
    /*
     * Use devide and conquor technique to find most matched index
     */
    public int computeLongitudeElevationIndex(double longitude) {
        
        int longElevIndex = -1;
        int longitudeIntegerValue = (int) longitude;
        
        double longitudeDecimalValue = longitude - longitudeIntegerValue;
        int currentLongitudeIndex = 0;
        double currentLongitudeValue = 0;
        double lastLongitudeValue = 0;
        int startIndexRange = 0;
        int maxIndexRange = 0;
        
        //check to make sure that the are a positive number of rows and the interval exists
        if (m_LongitudeProfileCount > 0 && m_LongitudeIntervalDeg > 0) {
            
            if (longitude == m_CellMaxLongitudeValue) {
                currentLongitudeValue = m_CellMaxLongitudeValue;
                currentLongitudeIndex = m_LongitudeProfileCount - 1;
            } else if (longitude == m_CellMinLongitudeValue) {
                currentLongitudeValue = m_CellMinLongitudeValue;
                currentLongitudeIndex = 0;
            } else {
                if (longitude <= m_Cell25PercentLongitudeValue) {
                    startIndexRange = 0;
                    maxIndexRange = m_LongitudeProfileCount / 4;
                } else if (longitude <= m_Cell50PercentLongitudeValue) {
                    startIndexRange = 0;
                    maxIndexRange = m_LongitudeProfileCount / 2;
                } else if (longitude > m_Cell50PercentLongitudeValue && longitude <= m_Cell75PercentLongitudeValue) {
                    startIndexRange = m_LongitudeProfileCount / 2;
                    maxIndexRange = m_LongitudeProfileCount * 3 / 4;
                } else if (longitude > m_Cell75PercentLongitudeValue) {
                    startIndexRange = m_LongitudeProfileCount * 3 / 4;
                    maxIndexRange = m_LongitudeProfileCount - 1;
                }
                for (int i = startIndexRange; i < maxIndexRange; i++) {
                    currentLongitudeValue = m_LongitudeOfOriginDeg + (i * m_LongitudeIntervalDeg);
                    currentLongitudeIndex = i;
                    if (currentLongitudeValue >= longitude) {
                        break;
                    }
                    lastLongitudeValue = currentLongitudeValue;
                }
            }
            longElevIndex = qualifyLongitudeIndex(currentLongitudeIndex, currentLongitudeValue);
        }
        return longElevIndex;
    }
    /*
     * Use devide and conquor technique to find most matched index
     */
    public int computeLatitudeElevationIndex(double latitude) {
        int latElevIndex = -1;
        int latitudeInteverValue = (int) latitude;
        double latitudeDecimalValue = latitude - latitudeInteverValue;
        int currentLatitudeIndex = 0;
        double currentLatitudeValue = 0;
        double lastLatitudeValue = 0;
        int startIndexRange = 0;
        int maxIndexRange = 0;
        //System.out.println("computeLatitudeElevationIndex for latitude: " + latitude);
        //System.out.println("m_LatitudeCountPerLongitudeLine: " + m_LatitudeCountPerLongitudeLine + ", m_LatitudeIntervalDeg: " + m_LatitudeIntervalDeg);
        if (m_LatitudeCountPerLongitudeLine > 0 && m_LatitudeIntervalDeg > 0) {
            if (latitude == m_CellMaxLatitudeValue) {
                currentLatitudeValue = m_CellMaxLatitudeValue;
                currentLatitudeIndex = m_LatitudeCountPerLongitudeLine - 1;
            } else if (latitude == m_CellMinLatitudeValue) {
                currentLatitudeValue = m_CellMinLatitudeValue;
                currentLatitudeIndex = 0;
            } else {
                if (latitude <= m_Cell25PercentLatitudeValue) {
                    startIndexRange = 0;
                    maxIndexRange = m_LatitudeCountPerLongitudeLine / 4;
                } else if (latitude <= m_Cell50PercentLatitudeValue) {
                    startIndexRange = 0;
                    maxIndexRange = m_LatitudeCountPerLongitudeLine / 2;
                } else if (latitude > m_Cell50PercentLatitudeValue && latitude <= m_Cell75PercentLatitudeValue) {
                    startIndexRange = m_LatitudeCountPerLongitudeLine / 2;
                    maxIndexRange = m_LatitudeCountPerLongitudeLine * 3 / 4;
                    //System.out.println("startIndexRange: " + startIndexRange + ", maxIndexRange: " + maxIndexRange);
                } else if (latitude > m_Cell75PercentLatitudeValue) {
                    startIndexRange = m_LatitudeCountPerLongitudeLine * 3 / 4;
                    maxIndexRange = m_LatitudeCountPerLongitudeLine - 1;
                }
                for (int i = startIndexRange; i < maxIndexRange; i++) {
                    currentLatitudeValue = m_LatitudeOfOriginDeg + (i * m_LatitudeIntervalDeg);
                    currentLatitudeIndex = i;
                    //System.out.println("currentLatitudeValue: " + currentLatitudeValue + ", currentLatitudeIndex: " + currentLatitudeIndex);
                    if (currentLatitudeValue >= latitude) {
                        break;
                    }
                    lastLatitudeValue = currentLatitudeValue;
                }
            }
            latElevIndex = qualifyLatitudeIndex(currentLatitudeIndex, currentLatitudeValue);
        }
        return latElevIndex;
    }
    /*
     * Set DTED cell max lon
     */
    public void setCellMaxLongitudeValue(int longitudeProfileCount, double longitudeIntervalDeg) {
        m_CellMaxLongitudeValue = m_LongitudeOfOriginDeg + ((longitudeProfileCount - 1) * longitudeIntervalDeg);
        //System.out.println("m_CellMaxLongitudeValue: " + m_CellMaxLongitudeValue);
    }
    /*
     * Set DTED cell min lon
     */
    public void setCellMinLongitudeValue(int longitudeProfileCount, double longitudeIntervalDeg) {
        m_CellMinLongitudeValue = m_LongitudeOfOriginDeg;
        //System.out.println("m_CellMinLongitudeValue: " + m_CellMinLongitudeValue);
    }
    /*
     * Set DTED cell 75% lon from cell bottom left corner
     */
    public void setCell75PercentLongitudeValue(int longitudeProfileCount, double longitudeIntervalDeg) {
        m_Cell75PercentLongitudeValue = m_LongitudeOfOriginDeg + ((longitudeProfileCount - 1) * longitudeIntervalDeg * 3.0d / 4.0d);
        //System.out.println("m_Cell75PercentLongitudeValue: " + m_Cell75PercentLongitudeValue);
    }
    /*
     * Set DTED cell 50% lon from cell bottom left corner
     */
    public void setCell50PercentLongitudeValue(int longitudeProfileCount, double longitudeIntervalDeg) {
        m_Cell50PercentLongitudeValue = m_LongitudeOfOriginDeg + ((longitudeProfileCount - 1) * longitudeIntervalDeg * 1.0d / 2.0d);
        //System.out.println("m_Cell50PercentLongitudeValue: " + m_Cell50PercentLongitudeValue);
    }
    /*
     * Set DTED cell 25% lon from cell bottom left corner
     */
    public void setCell25PercentLongitudeValue(int longitudeProfileCount, double longitudeIntervalDeg) {
        m_Cell25PercentLongitudeValue = m_LongitudeOfOriginDeg + ((longitudeProfileCount - 1) * longitudeIntervalDeg * 1.0d / 4.0d);
        //System.out.println("m_Cell25PercentLongitudeValue: " + m_Cell25PercentLongitudeValue);
    }
    /*
     * Set DTED cell max lat from bottom left corner
     */
    public void setCellMaxLatitudeValue(int latitudeCountPerLongitudeLine, double latitudeIntervalDeg) {
        m_CellMaxLatitudeValue = m_LatitudeOfOriginDeg + ((latitudeCountPerLongitudeLine - 1) * latitudeIntervalDeg);
        //System.out.println("m_CellMaxLatitudeValue: " + m_CellMaxLatitudeValue);
    }
    /*
     * Set DTED cell min lat from bottom left corner
     */
    public void setCellMinLatitudeValue(int latitudeCountPerLongitudeLine, double latitudeIntervalDeg) {
        m_CellMinLatitudeValue = m_LatitudeOfOriginDeg;
        //System.out.println("m_CellMinLatitudeValue: " + m_CellMinLatitudeValue);
    }
    /*
     * Set DTED cell 75% lat from bottom left corner
     */
    public void setCell75PercentLatitudeValue(int latitudeCountPerLongitudeLine, double latitudeIntervalDeg) {
        m_Cell75PercentLatitudeValue = m_LatitudeOfOriginDeg + ((latitudeCountPerLongitudeLine - 1) * latitudeIntervalDeg * 3.0d / 4.0d);
        //System.out.println("m_Cell75PercentLatitudeValue: " + m_Cell75PercentLatitudeValue);
    }
    /*
     * Set DTED cell 50% lat from bottom left corner
     */
    public void setCell50PercentLatitudeValue(int latitudeCountPerLongitudeLine, double latitudeIntervalDeg) {
        m_Cell50PercentLatitudeValue = m_LatitudeOfOriginDeg + ((latitudeCountPerLongitudeLine - 1) * latitudeIntervalDeg * 1.0d / 2.0d);
        //System.out.println("m_Cell50PercentLatitudeValue: " + m_Cell50PercentLatitudeValue);
    }
    /*
     * Set DTED cell 25% lat from bottom left corner
     */
    public void setCell25PercentLatitudeValue(int latitudeCountPerLongitudeLine, double latitudeIntervalDeg) {
        m_Cell25PercentLatitudeValue = m_LatitudeOfOriginDeg + ((latitudeCountPerLongitudeLine - 1) * latitudeIntervalDeg * 1.0d / 4.0d);
        //System.out.println("m_Cell25PercentLatitudeValue: " + m_Cell25PercentLatitudeValue);
    }
    
    /*
     * Find closest lon post within cell
     */
    public int qualifyLongitudeIndex(int currentLongitudeIndex, double currentLongitudeValue) {
        int qualifiedIndex = 0;
        double deltaLongitude = m_Longitude - currentLongitudeValue;
        //System.out.println("currentLongitudeIndex: " + currentLongitudeIndex + ", currentLongitudeValue: " + currentLongitudeValue);
        if (deltaLongitude <= m_LongitudeIntervalDeg / 2.0d) {
            qualifiedIndex = currentLongitudeIndex - 1;
        } else {
            qualifiedIndex = currentLongitudeIndex;
        }
        if (qualifiedIndex < 0) {
            qualifiedIndex = 0;
        } else if (qualifiedIndex > m_LongitudeProfileCount - 1) {
            qualifiedIndex = m_LongitudeProfileCount - 1;
        }
        return qualifiedIndex;
    }
    /*
     * Find closest lat post within cell
     */
    public int qualifyLatitudeIndex(int currentLatitudeIndex, double currentLatitudeValue) {
        int qualifiedIndex = 0;
        double deltaLatitude = m_Latitude - currentLatitudeValue;
        
        //System.out.println("currentLatitudeIndex: " + currentLatitudeIndex + ", currentLatitudeValue: " + currentLatitudeValue);
        if (deltaLatitude <= m_LatitudeIntervalDeg / 2.0d) {
            qualifiedIndex = currentLatitudeIndex - 1;
        
        } else {
            qualifiedIndex = currentLatitudeIndex;
        
        }
        if (qualifiedIndex < 0) {
            qualifiedIndex = 0;
        
        } else if (qualifiedIndex > m_LatitudeCountPerLongitudeLine - 1) {
            qualifiedIndex = m_LatitudeCountPerLongitudeLine - 1;
        }
        
        return qualifiedIndex;
    }
}