package elevationprofiler.dted;


/*
*
* CLASSIFICATION:       UNCLASSIFIED
*
*  CSCI:                DTED file processor
*
*  HISTORY:
*
*   Date      PTR#      Name     Description and Procedures
*   MM/DD/YY  ######    Inits
*   --------  --------  -----    ---------------------------
*   07/01/11  004994    TD       Creation
*
*/

/*
* DETED File Info
 * 
 * A container for storing the file data of the DTED object
*/
class DTED_Info {
    
    // Partial fields of Data Record
    public int      m_DataBlockCnt; // block size?
    public double[] m_ElevPointNmeter;
    public double   m_LatIntervalIn10thSec;
    public int      m_LatIntervalSec;
    public char     m_LatOrigLess10DegHemisphere;
    
    // Partial fields of Data Set Identification(DSI) Record
    public double m_LatOrigLess10deg;
    public int    m_LattitudeCount;
    public double m_LongIntervalIn10thSec;
    public int    m_LongIntervalSec;
    public double m_LongOrigLess100deg;
    public char   m_LongOrigLess100degHemisphere;
    public int    m_LongitudeCount;
    public double m_UHLLatOrig;
    public char   m_UHLLatOrigHemisphere;
    
    // Partial fields of User Header Label (UHL)
    public double m_UHLLongOrig;
    public char   m_UHLLongOrigHemisphere;
    
    /*
     *
     * Empty constructor
     *
     */
    public DTED_Info() {}
    
    /*
     *
     * Set  User Header Label (UHL)Longitude of Origin
     *
     */
    public void setUHLLongOrig(double longOrig) {
        m_UHLLongOrig = longOrig;
    }
    
    /*
     *
     * Set UHL Longitude of Origin Hemisphere
     *
     */
    public void setUHLLongOrigHemisphere(char hemisphere) {
        m_UHLLongOrigHemisphere = hemisphere;
    }
    
    /*
     *
     * Set UHL Latitude of Origin
     *
     */
    
    public void setUHLLatOrig(double longOrig) {
        m_UHLLatOrig = longOrig;
    }
    
    /*
     *
     * Set UHL Latitude of Origin Hemisphere
     *
     */
    public void setUHLLatOrigHemisphere(char hemisphere) {
        m_UHLLatOrigHemisphere = hemisphere;
    }
    
    /*
     *
     *  Set Longitude Interval in Sec
     *
     */
    public void setLongitudeIntervalSec(int interval) {
        m_LongIntervalSec = interval;
    }
    
    /*
     *
     * Set Latitude Interval in Sec
     *
     */
    public void setLattitudeIntervalSec(int interval) {
        m_LatIntervalSec = interval;
    }
    
    /*
     *
     * Set Latitude of Origin Less Than Tens Deg Group
     *
     */
    public void setLatOrgLess10Deg(double longitude) {
        m_LatOrigLess10deg = longitude;
    }
    
    /*
     *
     * Set Latitude of Origin Less Than Tens Deg Group Hemisphere
     *
     */
    public void setLatOrgLess10DegHemisphere(char hemisphere) {
        m_LatOrigLess10DegHemisphere = hemisphere;
    }
    
    /*
     *
     * Set Longitude of Origin Less Than Hundreds Deg Group
     *
     */
    public void setLongOrigLess100Deg(double longitude) {
        m_LongOrigLess100deg = longitude;
    }
    
    /*
     *
     * Set Longitude of Origin Less Than Hundreds Deg Group Hemisphere
     *
     */
    public void setLongOrigLess100DegHemisphere(char hemisphere) {
        m_LongOrigLess100degHemisphere = hemisphere;
    }
    
    /*
     *
     * Set Latitude Interval In Tenth Sec Group
     *
     */
    public void setLatIntervalIn10thSec(double interval) {
        m_LatIntervalIn10thSec = interval;
    }
    
    /*
     *
     * Set Longitude Interval in Tenth Sec Group
     *
     */
    public void setLongIntervalIn10thSec(double interval) {
        m_LongIntervalIn10thSec = interval;
    }
    
    /*
     *
     * Set Data Block Count
     *
     */
    public void setDataBlockCount(int count) {
        m_DataBlockCnt = count;
    }
    
    /*
     *
     * Set Longitude Count
     *
     */
    public void setLongitudeCount(int count) {
        m_LongitudeCount = count;
        if (m_LongitudeCount > 0) {
            m_ElevPointNmeter = new double[m_LongitudeCount];
        }
    }
    
    /*
     *
     * Set Latitude Count
     *
     */
    public void setLatitudeCount(int count) {
        m_LattitudeCount = count;
    }
    
    /*
     *
     * Set Elevation Point Per Given Index
     *
     */
    public void setElevationPoint(int index, int elevation) {
        m_ElevPointNmeter[index] = elevation;
    }
}