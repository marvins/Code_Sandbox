/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;


import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
/*
 *
 * CLASSIFICATION:       UNCLASSIFIED
 *
 *  CSCI:                DTED file processor
 *
 *  HISTORY:
 *
 *   Date      PTR#      Name     Description and Procedures
 *   MM/DD/YY  ######    Inits
 *   --------  --------  -----    ---------------------------
 *   07/01/11  004994    TD       Creation
 *
 */
/*
 *DTED Data Set Identification (DSI) Record
 */
class DTED_Dsi_Record {
    
    public byte[] m_SentinelRaw = new byte[3];
    public byte[] m_DesignatorRaw = new byte[5];
    public byte[] m_LatitudeOfOriginRaw = new byte[8];
    public byte m_LatitudeOfOriginHemisphere;
    public byte[] m_LongitudeOfOriginRaw = new byte[9];
    public byte m_LongitudeOfOriginHemisphere;
    public byte[] m_LatitudeSWRaw = new byte[6];
    public byte m_LatitudeSWHemisphere;
    public byte[] m_LongitudeSWRaw = new byte[7];
    public byte m_LongitudeSWHemisphere;
    public byte[] m_LatitudeNWRaw = new byte[6];
    public byte m_LatitudeNWHemisphere;
    public byte[] m_LongitudeNWRaw = new byte[7];
    public byte m_LongitudeNWHemisphere;
    public byte[] m_LatitudeNERaw = new byte[6];
    public byte m_LatitudeNEHemisphere;
    public byte[] m_LongitudeNERaw = new byte[7];
    public byte m_LongitudeNEHemisphere;
    public byte[] m_LatitudeSERaw = new byte[6];
    public byte m_LatitudeSEHemisphere;
    public byte[] m_LongitudeSERaw = new byte[7];
    public byte m_LongitudeSEHemisphere;
    public int m_LatitudeIntervalInTenthsOfSecBetweenRows;
    public int m_LongitudeIntervalInTenthsOfSecBetweenCols;
    public int m_NumberofLatitudeLines;
    public int m_NumberofLongitudeLines;
    public String m_SentinelStr;
    public String m_DesignatorStr;
    public double m_LatitudeOfOriginDeg;
    public double m_LongitudeOfOriginDeg;
    public double m_LatitudeSWDeg;
    public double m_LongitudeSWDeg;
    public double m_LatitudeNWDeg;
    public double m_LongitudeNWDeg;
    public double m_LatitudeNEDeg;
    public double m_LongitudeNEDeg;
    public double m_LatitudeSEDeg;
    public double m_LongitudeSEDeg;
    /*
     * Constructor
     */
    public DTED_Dsi_Record(ByteBuffer buff) {
        m_SentinelRaw[0] = buff.get(0);
        m_SentinelRaw[1] = buff.get(1);
        m_SentinelRaw[2] = buff.get(2);
        m_DesignatorRaw[0] = buff.get(59);
        m_DesignatorRaw[1] = buff.get(60);
        m_DesignatorRaw[2] = buff.get(61);
        m_DesignatorRaw[3] = buff.get(62);
        m_DesignatorRaw[4] = buff.get(63);
        m_LatitudeOfOriginRaw[0] = buff.get(185);
        m_LatitudeOfOriginRaw[1] = buff.get(186);
        m_LatitudeOfOriginRaw[2] = buff.get(187);
        m_LatitudeOfOriginRaw[3] = buff.get(188);
        m_LatitudeOfOriginRaw[4] = buff.get(189);
        m_LatitudeOfOriginRaw[5] = buff.get(190);
        m_LatitudeOfOriginRaw[6] = buff.get(191);
        m_LatitudeOfOriginRaw[7] = buff.get(192);
        m_LatitudeOfOriginHemisphere = buff.get(193);
        m_LongitudeOfOriginRaw[0] = buff.get(194);
        m_LongitudeOfOriginRaw[1] = buff.get(195);
        m_LongitudeOfOriginRaw[2] = buff.get(196);
        m_LongitudeOfOriginRaw[3] = buff.get(197);
        m_LongitudeOfOriginRaw[4] = buff.get(198);
        m_LongitudeOfOriginRaw[5] = buff.get(199);
        m_LongitudeOfOriginRaw[6] = buff.get(200);
        m_LongitudeOfOriginRaw[7] = buff.get(201);
        m_LongitudeOfOriginRaw[8] = buff.get(202);
        m_LongitudeOfOriginHemisphere = buff.get(203);
        m_LatitudeSWRaw[0] = buff.get(204);
        m_LatitudeSWRaw[1] = buff.get(205);
        m_LatitudeSWRaw[2] = buff.get(206);
        m_LatitudeSWRaw[3] = buff.get(207);
        m_LatitudeSWRaw[4] = buff.get(208);
        m_LatitudeSWRaw[5] = buff.get(209);
        m_LatitudeSWHemisphere = buff.get(210);
        m_LongitudeSWRaw[0] = buff.get(211);
        m_LongitudeSWRaw[1] = buff.get(212);
        m_LongitudeSWRaw[2] = buff.get(213);
        m_LongitudeSWRaw[3] = buff.get(214);
        m_LongitudeSWRaw[4] = buff.get(215);
        m_LongitudeSWRaw[5] = buff.get(216);
        m_LongitudeSWRaw[6] = buff.get(217);
        m_LongitudeSWHemisphere = buff.get(218);
        m_LatitudeNWRaw[0] = buff.get(219);
        m_LatitudeNWRaw[1] = buff.get(220);
        m_LatitudeNWRaw[2] = buff.get(221);
        m_LatitudeNWRaw[3] = buff.get(222);
        m_LatitudeNWRaw[4] = buff.get(223);
        m_LatitudeNWRaw[5] = buff.get(224);
        m_LatitudeNWHemisphere = buff.get(225);
        m_LongitudeNWRaw[0] = buff.get(226);
        m_LongitudeNWRaw[1] = buff.get(227);
        m_LongitudeNWRaw[2] = buff.get(228);
        m_LongitudeNWRaw[3] = buff.get(229);
        m_LongitudeNWRaw[4] = buff.get(230);
        m_LongitudeNWRaw[5] = buff.get(231);
        m_LongitudeNWRaw[6] = buff.get(232);
        m_LongitudeNWHemisphere = buff.get(233);
        m_LatitudeNERaw[0] = buff.get(234);
        m_LatitudeNERaw[1] = buff.get(235);
        m_LatitudeNERaw[2] = buff.get(236);
        m_LatitudeNERaw[3] = buff.get(237);
        m_LatitudeNERaw[4] = buff.get(238);
        m_LatitudeNERaw[5] = buff.get(239);
        m_LatitudeNEHemisphere = buff.get(240);
        m_LongitudeNERaw[0] = buff.get(241);
        m_LongitudeNERaw[1] = buff.get(242);
        m_LongitudeNERaw[2] = buff.get(243);
        m_LongitudeNERaw[3] = buff.get(244);
        m_LongitudeNERaw[4] = buff.get(245);
        m_LongitudeNERaw[5] = buff.get(246);
        m_LongitudeNERaw[6] = buff.get(247);
        m_LongitudeNEHemisphere = buff.get(248);
        m_LatitudeSERaw[0] = buff.get(249);
        m_LatitudeSERaw[1] = buff.get(250);
        m_LatitudeSERaw[2] = buff.get(251);
        m_LatitudeSERaw[3] = buff.get(252);
        m_LatitudeSERaw[4] = buff.get(253);
        m_LatitudeSERaw[5] = buff.get(254);
        m_LatitudeSEHemisphere = buff.get(255);
        m_LongitudeSERaw[0] = buff.get(256);
        m_LongitudeSERaw[1] = buff.get(257);
        m_LongitudeSERaw[2] = buff.get(258);
        m_LongitudeSERaw[3] = buff.get(259);
        m_LongitudeSERaw[4] = buff.get(260);
        m_LongitudeSERaw[5] = buff.get(261);
        m_LongitudeSERaw[6] = buff.get(263);
        m_LongitudeSEHemisphere = buff.get(264);
        m_LatitudeIntervalInTenthsOfSecBetweenRows = buff.getInt(273);
        m_LongitudeIntervalInTenthsOfSecBetweenCols = buff.getInt(277);
        m_NumberofLatitudeLines = buff.getInt(281);
        m_NumberofLongitudeLines = buff.getInt(285);
        m_SentinelStr = new String(m_SentinelRaw);
//        System.out.println("DTED_Dsi_Record-m_Sentinel: " + m_SentinelStr);
        m_DesignatorStr = new String(m_DesignatorRaw);
//        System.out.println("DTED_Dsi_Record-m_DesignatorStr: " + m_DesignatorStr);
    }
    
    
    /*
     * Convert All Longitudes to Deg
     */
    public void convertAllLongitudesToDeg() {
        
        //load DEGREES
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LongitudeOfOriginRaw, 0, 3);
        IntBuffer ibDeg = bbDeg.asIntBuffer();
        int degVal = ibDeg.get(0);
        
        ByteBuffer bbMin = ByteBuffer.wrap(m_LongitudeOfOriginRaw, 3, 2);
        ShortBuffer sbMin = bbMin.asShortBuffer();
        int minVal = sbMin.get(0);
        String secStr = new String(m_LatitudeOfOriginRaw, 4, 4);
        double secVal = Double.parseDouble(secStr);
        m_LongitudeOfOriginDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        
        
        bbDeg = ByteBuffer.wrap(m_LongitudeSWRaw, 0, 3);
        ibDeg = bbDeg.asIntBuffer();
        degVal = ibDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LongitudeSWRaw, 3, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LongitudeSWRaw, 5, 2);
        secVal = Double.parseDouble(secStr);
        m_LongitudeSWDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LongitudeNWRaw, 0, 3);
        ibDeg = bbDeg.asIntBuffer();
        degVal = ibDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LongitudeNWRaw, 3, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LongitudeNWRaw, 5, 2);
        secVal = Double.parseDouble(secStr);
        m_LongitudeNWDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LongitudeNERaw, 0, 3);
        ibDeg = bbDeg.asIntBuffer();
        degVal = ibDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LongitudeNERaw, 3, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LongitudeNERaw, 5, 2);
        secVal = Double.parseDouble(secStr);
        m_LongitudeNEDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LongitudeSERaw, 0, 3);
        ibDeg = bbDeg.asIntBuffer();
        degVal = ibDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LongitudeSERaw, 3, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LongitudeSERaw, 5, 2);
        secVal = Double.parseDouble(secStr);
        m_LongitudeSEDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
    }
    
    
    /*
     * Convert All Latitudes To Deg
     */
    public void convertAllLatitudesToDeg() {
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LatitudeOfOriginRaw, 0, 2);
        ShortBuffer isbDeg = bbDeg.asShortBuffer();
        int degVal = isbDeg.get(0);
        ByteBuffer bbMin = ByteBuffer.wrap(m_LatitudeOfOriginRaw, 2, 2);
        ShortBuffer sbMin = bbMin.asShortBuffer();
        int minVal = sbMin.get(0);
        String secStr = new String(m_LatitudeOfOriginRaw, 4, 4);
        double secVal = Double.parseDouble(secStr);
        m_LatitudeOfOriginDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LatitudeSWRaw, 0, 2);
        isbDeg = bbDeg.asShortBuffer();
        degVal = isbDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LatitudeSWRaw, 2, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LatitudeSWRaw, 4, 2);
        secVal = Double.parseDouble(secStr);
        m_LatitudeSWDeg = (double) degVal + minVal * 1 / 60.0 + secVal * 1 / 60.0 * 1 / 60.0;
        bbDeg = ByteBuffer.wrap(m_LatitudeNWRaw, 0, 2);
        isbDeg = bbDeg.asShortBuffer();
        degVal = isbDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LatitudeNWRaw, 2, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LatitudeNWRaw, 4, 2);
        secVal = Double.parseDouble(secStr);
        m_LatitudeNWDeg = (double) degVal + minVal * 1 / 60.0 + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LatitudeNERaw, 0, 2);
        isbDeg = bbDeg.asShortBuffer();
        degVal = isbDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LatitudeNERaw, 2, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LatitudeNERaw, 4, 2);
        secVal = Double.parseDouble(secStr);
        m_LatitudeNEDeg = (double) degVal + ((minVal * 1 / 60.0) + secVal * 1 / 60.0 * 1 / 60.0);
        bbDeg = ByteBuffer.wrap(m_LatitudeSERaw, 0, 2);
        isbDeg = bbDeg.asShortBuffer();
        degVal = isbDeg.get(0);
        bbMin = ByteBuffer.wrap(m_LatitudeSERaw, 2, 2);
        sbMin = bbMin.asShortBuffer();
        minVal = sbMin.get(0);
        secStr = new String(m_LatitudeSERaw, 4, 2);
        secVal = Double.parseDouble(secStr);
        m_LatitudeSEDeg = (double) degVal + minVal * 1 / 60.0 + secVal * 1 / 60.0 * 1 / 60.0;
    }
}