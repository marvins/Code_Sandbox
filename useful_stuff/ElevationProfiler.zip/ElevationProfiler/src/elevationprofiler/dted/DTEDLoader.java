/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

import elevationprofiler.geographic.GeodeticDD;
import java.io.FileNotFoundException;

/**
 * Contains utilities for extracting relevant information from DTED data.
 *
 * @author ms6401
 */
public class DTEDLoader {

    /**
     * Compute the elevation of a particular lat/long coordinate.
     *
     * @param coord coordinate in decimal degree string format
     * @return the elevation in meters
     */
    public static double point2ElevationMeters(GeodeticDD coord) throws FileNotFoundException {

        
        //convert the coordinate into the proper format
        Point pt = convertCoordinate(coord);

        //push coordinate into constructor
        DTEDFile temp = new DTEDFile(pt.latH, pt.lat, pt.lonH, pt.lon);

        //return the result in meters
        return temp.getEmitterElevationInMeter();
    }
    
    /**
     * Compute the elevation of a particular lat/long coordinate.
     *
     * @param coord coordinate in a Geodetic Decimal Degree string format
     * @return the elevation in meters
     */
    public static double point2ElevationMeters(GeodeticDD coord, String data_directory) throws FileNotFoundException {

        //convert the coordinate into the proper format
        Point pt = convertCoordinate(coord);

        //push coordinate into constructor
        DTEDFile temp = new DTEDFile(pt.latH, pt.lat, pt.lonH, pt.lon, data_directory);

        //return the result in meters
        return temp.getEmitterElevationInMeter();

    }

    /**
     * Compute the elevation of a particular lat/long coordinate.
     *
     * @param coord coordinate in Geodetic Decimal Degree string format
     * @return the elevation in feet
     */
    public static double point2ElevationFeet(GeodeticDD coord) throws FileNotFoundException {


        Point pt = convertCoordinate(coord);

        DTEDFile temp = new DTEDFile(pt.latH, pt.lat, pt.lonH, pt.lon);

        return temp.getEmitterElevationInFt();
    }

    /**
     * Compute a Point object for the input string coordinate. Note that function will 
     * try its best to convert the point given any GeoDD coordinate format.
     * @param coord Geodetic Decimal Degree coordinate
     * @return Point object
     */
    private static Point convertCoordinate(GeodeticDD coord) {

        Point pt = new Point();

        pt.lat = coord.lat;
        pt.lon = coord.lon;
        
        if( coord.lat >= 0 ) {
            pt.latH = "N";
        }
        else {
            pt.latH = "S";
        }
        
        if( coord.lon >= 0 ) {
            pt.lonH = "E";
        }
        else {
            pt.lonH = "W";
        }

        return pt;
    }
}
