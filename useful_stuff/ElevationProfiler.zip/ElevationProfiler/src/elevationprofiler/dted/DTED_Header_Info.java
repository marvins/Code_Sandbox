/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

/**
 *
 * @author ms6401
 */
class DTED_Header_Info {
    
    //useful const variables
    final public int    DTED_ACC_SIZE = 2700;
    final public int    DTED_DSI_SIZE = 648;
    final public int    DTED_UHL_SIZE = 80;
    final public double FT_TO_METER = 0.3048d; /*< Conversion variable for meter2ft conversion*/
    
    //this is the lat/long of the coordinate to pull at
    public double latitude;
    public double longitude;
    
    // this is used to find the file
    public String latHemisphere;
    public String lonHemisphere;
    
    //file location info
    public String rootDirectoryName;
    
    //discovered elevation
    public double elevation;
    
    //dted image information
    public int m_LongitudeProfileCount;
    public int m_LatitudeCountPerLongitudeLine;
    
    
    
}
