package elevationprofiler.dted;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*
 *
 * CLASSIFICATION: UNCLASSIFIED
 *
 * CSCI: DTED file processor
 *
 * HISTORY:
 *
 * Date PTR# Name Description and Procedures MM/DD/YY ###### Inits --------
 * -------- ----- --------------------------- 07/01/11 004994 TD Creation
 *
 */

class DTEDFile {

    // Class variables
    private DTED_Header_Info img_data;

    /**
     * DTED File constructor given no DTED directory input
     *
     * @param latitudeHemisphere Hemisphere for the latitude
     * @param latitude Latitude in decimal degrees
     * @param longitudeHemisphere Hemisphere for the longitude
     * @param longitude Longitude in decimal degrees
     */
    public DTEDFile(String latitudeHemisphere, double latitude, String longitudeHemisphere, double longitude) throws FileNotFoundException {

        //initialize all pertinant information
        img_data = new DTED_Header_Info();

        //init lat long info
        img_data.latitude = latitude;
        img_data.latHemisphere = latitudeHemisphere;
        img_data.longitude = longitude;
        img_data.lonHemisphere = longitudeHemisphere;

        //file info
        img_data.rootDirectoryName = getDTECdirectory(false, null);
        getDTEDFile();

    }

    /**
     * DTED File constructor given an input DTED directory
     *
     * @param latitudeHemisphere latitude hemisphere
     * @param latitude latitude coordinate
     * @param longitudeHamisphere longitude hemisphere
     * @param longitude longitude coordinate
     * @param data_dir Directory of the root data
     */
    public DTEDFile(String latitudeHemisphere, double latitude, String longitudeHemisphere, double longitude, String data_dir) throws FileNotFoundException {

        img_data = new DTED_Header_Info();

        //initialize all pertinant information
        img_data = new DTED_Header_Info();

        //init lat long info
        img_data.latitude = latitude;
        img_data.latHemisphere = latitudeHemisphere;
        img_data.longitude = longitude;
        img_data.lonHemisphere = longitudeHemisphere;

        //file info
        img_data.rootDirectoryName = getDTECdirectory(true, data_dir);

        getDTEDFile();

    }

    /**
     * Get DTED directory
     *
     * Will determine the directory of the dted data. The data will either
     * default to a particular directory or look up the DTED_ROOT_DIRECTORY env
     * variable
     *
     * @param inputValid boolean flag if you want to use data_dir input as
     * directory of choice. Otherwise, you will pull the DTED_ROOT_DIRECTORY
     * @param data_dir String which contains the name of the dted data root
     * directory. This directory will point to a folder which contains the
     * longitude directories
     * @return Name of valid and tested DTED directory
     *
     * @note I really should use regular expressions with file iteration rather
     * than build a list of possible files.
     */
    private String getDTECdirectory(boolean inputValid, String data_dir) {

        //execute this path if the input directory path is valid
        if (inputValid == true) {

            //make sure that input directory is not null
            if (data_dir == null) {
                throw new IllegalArgumentException("Error: if inputValid is true, then data_dir must not be null");
            } //otherwise, test directory existance
            else {
                String outputDirectoryString = data_dir;
                File outputDirectoryFile = new File(data_dir);
                if (!outputDirectoryFile.exists()) {
                    throw new IllegalArgumentException("Error: data_dir given does not exist");
                } else {
                    return outputDirectoryString;
                }
            }
        } //execute this path if you want to use the environment variable
        else if (inputValid == false) {

            //pull environment variable
            String outputDirectoryString = System.getenv("DTED_ROOT_DIRECTORY");

            //in case the root directory variable not set, throw exception
            if (outputDirectoryString == null) {
                throw new IllegalArgumentException("Error: given false inputValid input, you must set DTED_ROOT_DIRECTORY variable to a valid location");
            }

            //make sure that directory exists
            File outputDirectoryFile = new File(outputDirectoryString);
            if (!outputDirectoryFile.exists()) {
                throw new IllegalArgumentException("Error: DTED_ROOT_DIRECTORY environment variable location does not exist");
            }

            //now return 
            return outputDirectoryString;
        } //just in case inputValid is equal to null or something else weird
        else {
            throw new IllegalArgumentException("Error: inputValid variable must be true or false");
        }

    }

    /**
     * Acquire DTED data file for given lon/lat and hemisphere
     *
     */
    private void getDTEDFile() throws FileNotFoundException {

        /**
         * Get the proper dted file location
         *
         * 1. Do a floor operation on both lat and long 2. convert to string and
         * find proper directories
         */
        int lonNum = (int) Math.abs(Math.floor(img_data.longitude));
        int latNum = (int) Math.abs(Math.floor(img_data.latitude));

        String lonChar, latChar;
        if (img_data.longitude >= 0) {
            lonChar = "E";
        } else {
            lonChar = "W";
        }
        if (img_data.latitude >= 0) {
            latChar = "N";
        } else {
            latChar = "S";
        }

        File dted_basename = new File(img_data.rootDirectoryName);
        File lonDir = null, latFile = null;

        String regexStr = "[" + lonChar.toLowerCase() + lonChar.toUpperCase() + "]0*" + lonNum;
        Pattern pattern;
        Matcher matcher;

        String[] contents = dted_basename.list();
        for (String item : contents) {

            pattern = Pattern.compile(regexStr);

            matcher = pattern.matcher(item);

            boolean found = matcher.find();
            if (found == true) {
                lonDir = new File(dted_basename.getAbsolutePath() + '/' + item);
            }
        }

        //make sure that directory exists
        if( lonDir == null || lonDir.exists() == false ){
            throw new FileNotFoundException("Directory does not exist");
        }
        regexStr = "[" + latChar.toLowerCase() + latChar.toUpperCase() + "]0*" + latNum + ".dt[012]";
        contents = lonDir.list();
        for (String item : contents) {

            pattern = Pattern.compile(regexStr);
            matcher = pattern.matcher(item);

            boolean found = matcher.find();
            if (found == true) {
                latFile = new File(lonDir.getAbsolutePath() + '/' + item);
            }
        }

        //since the directory and file exist, now we need to make the call to process it
        // Initiate and process DTEDFile file from lon & lat information
        DTED_Info record = new DTED_Info();

        //process DTED File and load relevant internals
        ProcessDTEDFile processDTEDFile = new ProcessDTEDFile(record, latFile, img_data);

        try {
            processDTEDFile.Read_DTED_Uhl_Record();
            processDTEDFile.Read_DTED_Dsi_Record();
            processDTEDFile.Read_DTED_Acc_Record();
            DTED_Data_Record dataRecord = processDTEDFile.Read_DTED_Data_Record();

            if (dataRecord != null) {
                img_data.elevation = processDTEDFile.img_data.elevation;
            }
        } catch (IOException ex) {
            throw new IllegalArgumentException("Error: file parsing and loading failed");
        }
    }

    /**
     * Get DTED Emitter Elevation in Meter
     *
     * @return data elevation in meters
     */
    public double getEmitterElevationInMeter() {
        return img_data.elevation;
    }
    /*
     * Get DTED Emiter Elevation in Ft
     * 
     * @return elevation in feet
     */

    public double getEmitterElevationInFt() {
        return img_data.elevation / img_data.FT_TO_METER;
    }
}