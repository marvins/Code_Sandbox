/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

/**
 *
 * @author ms6401
 */
class Point {
    
    double lat;
    double lon;
    String latH;
    String lonH;
    
}
