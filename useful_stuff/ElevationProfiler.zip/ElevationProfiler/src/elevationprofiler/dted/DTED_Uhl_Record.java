/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

/*
 *
 * CLASSIFICATION:       UNCLASSIFIED
 *
 *  CSCI:                DTED file processor
 *
 *  HISTORY:
 *
 *   Date      PTR#      Name     Description and Procedures
 *   MM/DD/YY  ######    Inits
 *   --------  --------  -----    ---------------------------
 *   07/01/11  004994    TD       Creation
 *
 */
import java.nio.ByteBuffer;

/*
 *DTED User Header Label (UHL) segment
 */
class DTED_Uhl_Record {
    public byte[] m_SentinelRaw = new byte[3];
    public byte[] m_LongitudeOfOriginRaw = new byte[7];
    public byte m_LongitudeOfOriginHemisphere;
    public byte[] m_LatitudeOfOriginRaw = new byte[7];
    public byte m_LatitudeOfOriginHemisphere;
    public byte[] m_LongitudeDataIntervalSecRaw = new byte[4];
    public byte[] m_LattitudeDataIntervalSecRaw = new byte[4];
    public byte[] m_LongitudeProfileCountRaw = new byte[4];
    public byte[] m_LatitudeCountPerLongitudeLineRaw = new byte[4];
    public String m_SentinelStr;
    public double m_LongitudeOfOriginDeg;
    public double m_LatitudeOfOriginDeg;
    public double m_LongitudeDataIntervalSec;
    public double m_LattitudeDataIntervalSec;
    
    ///This is the number of rows 
    public int m_LongitudeProfileCount;
    public int m_LatitudeCountPerLongitudeLine;
    
    
    /*
     * Define DTED UHL Record from Byte Buffer Message
     */
    public DTED_Uhl_Record(ByteBuffer buff) {
        m_SentinelRaw[0] = buff.get(0);
        m_SentinelRaw[1] = buff.get(1);
        m_SentinelRaw[2] = buff.get(2);
        m_LongitudeOfOriginRaw[0] = buff.get(4);
        m_LongitudeOfOriginRaw[1] = buff.get(5);
        m_LongitudeOfOriginRaw[2] = buff.get(6);
        m_LongitudeOfOriginRaw[3] = buff.get(7);
        m_LongitudeOfOriginRaw[4] = buff.get(8);
        m_LongitudeOfOriginRaw[5] = buff.get(9);
        m_LongitudeOfOriginRaw[6] = buff.get(10);
        m_LongitudeOfOriginHemisphere = buff.get(11);
        m_LatitudeOfOriginRaw[0] = buff.get(12);
        m_LatitudeOfOriginRaw[1] = buff.get(13);
        m_LatitudeOfOriginRaw[2] = buff.get(14);
        m_LatitudeOfOriginRaw[3] = buff.get(15);
        m_LatitudeOfOriginRaw[4] = buff.get(16);
        m_LatitudeOfOriginRaw[5] = buff.get(17);
        m_LatitudeOfOriginRaw[6] = buff.get(18);
        m_LatitudeOfOriginHemisphere = buff.get(19);
        m_LongitudeDataIntervalSecRaw[0] = buff.get(20);
        m_LongitudeDataIntervalSecRaw[1] = buff.get(21);
        m_LongitudeDataIntervalSecRaw[2] = buff.get(22);
        m_LongitudeDataIntervalSecRaw[3] = buff.get(23);
        m_LattitudeDataIntervalSecRaw[0] = buff.get(24);
        m_LattitudeDataIntervalSecRaw[1] = buff.get(25);
        m_LattitudeDataIntervalSecRaw[2] = buff.get(26);
        m_LattitudeDataIntervalSecRaw[3] = buff.get(27);
        m_LongitudeProfileCountRaw[0] = buff.get(47);
        m_LongitudeProfileCountRaw[1] = buff.get(48);
        m_LongitudeProfileCountRaw[2] = buff.get(49);
        m_LongitudeProfileCountRaw[3] = buff.get(50);
        m_LatitudeCountPerLongitudeLineRaw[0] = buff.get(51);
        m_LatitudeCountPerLongitudeLineRaw[1] = buff.get(52);
        m_LatitudeCountPerLongitudeLineRaw[2] = buff.get(53);
        m_LatitudeCountPerLongitudeLineRaw[3] = buff.get(54);
        m_LongitudeOfOriginDeg = -1.0d;
        m_LatitudeOfOriginDeg = -1.0d;
        m_SentinelStr = new String(m_SentinelRaw);
        //System.out.println("DTED_Uhl_Record-m_Sentinel: " + m_SentinelStr);
    }
    
    
    /*
     * Convert Raw Longitude Profile Count To Integer
     */
    public void convertRawLongitudeProfileCountToInteger() {
        
        //wrap allows you to read a data stream like a normal input stream?
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LongitudeProfileCountRaw, 0, 4);
        
        //create a byte array of the data
        byte[] tempArray = new byte[bbDeg.remaining()];
        
        //load the array
        bbDeg.get(tempArray, 0, tempArray.length);
        
        //convert the byte data into a string
        String strDeg = new String(tempArray);
        if (strDeg != null) {
            m_LongitudeProfileCount = Integer.parseInt(strDeg);
        }
        //System.out.println("m_LongitudeProfileCount: " + m_LongitudeProfileCount);
    }
    
    /*
     * Convert Raw Latitude Count Per Longitude To Integer
     */
    public void convertRawLatitudeCountPerLongitudeLineToInteger() {
        
        //wrap the buffer to allow reading
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LatitudeCountPerLongitudeLineRaw, 0, 4);
        
        //pull data as bytes
        byte[] tempArray = new byte[bbDeg.remaining()];
        bbDeg.get(tempArray, 0, tempArray.length);
        
        //convert bytes to strings
        String strDeg = new String(tempArray);
        if (strDeg != null) {
            m_LatitudeCountPerLongitudeLine = Integer.parseInt(strDeg);
        }
        //System.out.println("m_LatitudeCountPerLongitudeLineRaw: " + m_LatitudeCountPerLongitudeLineRaw);
    }
    
    
    /*
     * Convert Raw Longitude Of Origin To Degree
     *  
     * NOTE:  Due to the corner being the origin, more than likely you should
     * read a cordinate of xd y' z'' as x.000 
     */
    public void convertRawLongitudeOfOriginToDegree() {
        
        //read from buffer, convert to string, then convert to int
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LongitudeOfOriginRaw, 0, 3);
        byte[] tempArray = new byte[bbDeg.remaining()];
        bbDeg.get(tempArray, 0, tempArray.length);
        String strDeg = new String(tempArray);
        int degVal = 0;
        if (strDeg != null) {
            degVal = Integer.parseInt(strDeg);
        }

        //System.out.println("Lon degVal: " + degVal);
        ByteBuffer bbMin = ByteBuffer.wrap(m_LongitudeOfOriginRaw, 3, 2);
        tempArray = new byte[bbMin.remaining()];
        bbMin.get(tempArray, 0, tempArray.length);
        String strMin = new String(tempArray);
        int minVal = 0;
        if (strMin != null) {
            minVal = Integer.parseInt(strMin);
        }
        
        ByteBuffer bbSec = ByteBuffer.wrap(m_LongitudeOfOriginRaw, 5, 2);
        tempArray = new byte[bbSec.remaining()];
        bbSec.get(tempArray, 0, tempArray.length);
        String strSec = new String(tempArray);
        int secVal = 0;
        if (strSec != null) {
            secVal = Integer.parseInt(strSec);
        }
        
        m_LongitudeOfOriginDeg = (double) degVal + minVal * 1 / 60.0 + secVal * 1 / 60.0 * 1 / 60.0;
        //System.out.println("Longitude of origin: " + m_LongitudeOfOriginDeg);
    }
    
    /**
     * Convert Raw Latitude Of Origin To Degree
     */
    public void convertRawLatitudeOfOriginToDegree() {
        //degree value
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LatitudeOfOriginRaw, 0, 3);
        byte[] tempArray = new byte[bbDeg.remaining()];
        bbDeg.get(tempArray, 0, tempArray.length);
        String strDeg = new String(tempArray);
        int degVal = 0;
        if (strDeg != null) {
            degVal = Integer.parseInt(strDeg);
        }
        
        //minute value
        //System.out.println("Lat degVal: " + degVal);
        ByteBuffer bbMin = ByteBuffer.wrap(m_LatitudeOfOriginRaw, 3, 2);
        tempArray = new byte[bbMin.remaining()];
        bbMin.get(tempArray, 0, tempArray.length);
        String strMin = new String(tempArray);
        int minVal = 0;
        if (strMin != null) {
            minVal = Integer.parseInt(strMin);
        }
        
        //second value
        //        System.out.println("Lat minVal: " + minVal);
        ByteBuffer bbSec = ByteBuffer.wrap(m_LatitudeOfOriginRaw, 5, 2);
        tempArray = new byte[bbSec.remaining()];
        bbSec.get(tempArray, 0, tempArray.length);
        String strSec = new String(tempArray);
        int secVal = 0;
        if (strSec != null) {
            secVal = Integer.parseInt(strSec);
        }
        //        System.out.println("Lat secVal: " + secVal);
        m_LatitudeOfOriginDeg = (double) degVal + (double) (minVal * 1 / 60.0) + (double) (secVal * 1 / 60.0 * 1 / 60.0);
        //System.out.println("m_LatitudeOfOriginDeg: " + m_LatitudeOfOriginDeg);
    }
    
    
    
    /*
     * Convert Longitude Interval Raw To Decimal
     */
    public void convertLongitudeIntervalRawToDecimal() {
        
        //read, then pull into proper format
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LongitudeDataIntervalSecRaw, 0, 4);
        byte[] tempArray = new byte[bbDeg.remaining()];
        bbDeg.get(tempArray, 0, tempArray.length);
        String strDeg = new String(tempArray);
        if (strDeg != null) {
            m_LongitudeDataIntervalSec = Integer.parseInt(strDeg);
            m_LongitudeDataIntervalSec = m_LongitudeDataIntervalSec / 10.0d;
            m_LongitudeDataIntervalSec = m_LongitudeDataIntervalSec * 1 / 60.0 * 1 / 60.0;
        }
    
    }
    
    /*
     * Convert Raw Latitude Interval To Decimal
     */
    public void convertLatitudeIntervalRawToDecimal() {
        ByteBuffer bbDeg = ByteBuffer.wrap(m_LattitudeDataIntervalSecRaw, 0, 4);
        byte[] tempArray = new byte[bbDeg.remaining()];
        bbDeg.get(tempArray, 0, tempArray.length);
        String strDeg = new String(tempArray);
        if (strDeg != null) {
            m_LattitudeDataIntervalSec = Integer.parseInt(strDeg);
            m_LattitudeDataIntervalSec = m_LattitudeDataIntervalSec / 10.0d;
            m_LattitudeDataIntervalSec = m_LattitudeDataIntervalSec * 1 / 60.0 * 1 / 60.0;
        }
    
    }
    
}