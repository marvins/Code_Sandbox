package elevationprofiler.dted;

/*
 *
 * CLASSIFICATION: UNCLASSIFIED
 * 
* CSCI: DTED
 * 
* HISTORY:
 * 
* Date PTR# Name Description and Procedures MM/DD/YY ###### Inits --------
 * -------- ----- --------------------------- 07/01/11 004994 TD Creation
 *
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;

/**
 * DTED Processing Class
 *
 * @author ms6401
 */
class ProcessDTEDFile {

    private ByteBuffer m_Buff;    // = ByteBuffer.allocateDirect(DTED_RECORD_SIZE);
    private ReadableByteChannel m_Channel;
    private FileInputStream m_Stream;
    
    DTED_Header_Info img_data;

    
    /**
     *
     * @param info  DTED_Information class
     * @param file  File to be loaded
     * @param img_data Current Header data to load
     * @throws FileNotFoundException
     */
    public ProcessDTEDFile(DTED_Info info, File file, DTED_Header_Info img_data )
            throws FileNotFoundException {
        
        
        m_Stream = new FileInputStream(file);
        m_Channel = m_Stream.getChannel();
        m_Buff = null;
        
        this.img_data = img_data;
        this.img_data.m_LongitudeProfileCount = 0;
        this.img_data.m_LatitudeCountPerLongitudeLine = 0;
        
    }

    /**
     * Obtain lon/lat profile from DTED UHL segment
     * @return @throws IOException
     */
    public DTED_Uhl_Record Read_DTED_Uhl_Record() throws IOException {
        
        //create Uhl Record
        DTED_Uhl_Record dtedUhlRecord;

        //create a buffer to read from
        m_Buff = ByteBuffer.allocateDirect(img_data.DTED_UHL_SIZE);

        //get the size of the channel buffer
        int readIn = m_Channel.read(m_Buff);
        if (readIn == img_data.DTED_UHL_SIZE) {

            //set the buffer to the zero position
            m_Buff.rewind();

            //create new uhl record
            dtedUhlRecord = new DTED_Uhl_Record(m_Buff);

            //invert the buffer
            m_Buff.flip();

            //convert longitude profile to integer ( This is the number of rows in the image
            dtedUhlRecord.convertRawLongitudeProfileCountToInteger();
            dtedUhlRecord.convertRawLatitudeCountPerLongitudeLineToInteger();

            //compute the centers of origin as degree values
            dtedUhlRecord.convertRawLongitudeOfOriginToDegree();
            dtedUhlRecord.convertRawLatitudeOfOriginToDegree();

            //this is the interval between each coordinate in the data
            dtedUhlRecord.convertLongitudeIntervalRawToDecimal();
            dtedUhlRecord.convertLatitudeIntervalRawToDecimal();

            //get the image size
            img_data.m_LongitudeProfileCount = dtedUhlRecord.m_LongitudeProfileCount;
            img_data.m_LatitudeCountPerLongitudeLine = dtedUhlRecord.m_LatitudeCountPerLongitudeLine;
            
        } else {
            return null;
        }


        return dtedUhlRecord;
    }

    // Obtain lon/lat profile from DTED DSI segment
    /**
     *
     * @return return the lat/long
     * @throws IOException
     */
    public DTED_Dsi_Record Read_DTED_Dsi_Record() throws IOException {
        
        DTED_Dsi_Record dtedDsiRecord;

        //get buffer from DTED file
        m_Buff = ByteBuffer.allocateDirect(img_data.DTED_DSI_SIZE);
        int readIn = m_Channel.read(m_Buff);

        if (readIn == img_data.DTED_DSI_SIZE) {
            m_Buff.rewind();
            
            //create record
            dtedDsiRecord = new DTED_Dsi_Record(m_Buff);
            m_Buff.flip();
        } else {
            return null;
        }

        return dtedDsiRecord;
    }

    /**
     * This function merely makes sure that the size is right
     * @return @throws IOException
     */
    public boolean Read_DTED_Acc_Record() throws IOException {
        
        boolean receivedValidSize;

        m_Buff = ByteBuffer.allocateDirect( img_data.DTED_ACC_SIZE);

        int readIn = m_Channel.read(m_Buff);

        //start reading the accuracy header
        if (readIn == img_data.DTED_ACC_SIZE) {
            //reset the buffer
            m_Buff.rewind();
            //invert the direction
            m_Buff.flip();
            receivedValidSize = true;
        } else {
            System.out.println("Read_DTED_Acc_Record FAILED to read DTED ACC RECORD SEGMENT");
            receivedValidSize = false;
        }

        return receivedValidSize;
    }

    /**
     * Derive elevation from DTED Data segment
     *
     * @return
     * @throws IOException
     */
    public DTED_Data_Record Read_DTED_Data_Record() throws IOException {

        DTED_Data_Record dtedDataRecord = null;

        // Each elevation is 2 bytes.  Preamble = 8 bytes and chsum = 4 bytes for every 1201 elev points
        int dataRecordSize = (2 * img_data.m_LongitudeProfileCount * img_data.m_LatitudeCountPerLongitudeLine)
                + (img_data.m_LatitudeCountPerLongitudeLine * 12);

        // allocate buffer and read data
        m_Buff = ByteBuffer.allocateDirect(dataRecordSize);
        int readIn = m_Channel.read(m_Buff);
        
        if (readIn == dataRecordSize ) {
            

            //reset the data buffer
            m_Buff.rewind();
            
            //create the record
            dtedDataRecord = new DTED_Data_Record(m_Buff);
            dtedDataRecord.setLongitudeProfileCount(img_data.m_LongitudeProfileCount);
            dtedDataRecord.setLatitudeCountPerLongitudeLine(img_data.m_LatitudeCountPerLongitudeLine);
            
            //start building indeces
            double maxLat = Math.ceil(  img_data.latitude );
            double minLat = Math.floor( img_data.latitude );
            double maxLon = Math.ceil(  img_data.longitude);
            double minLon = Math.floor( img_data.longitude);

            double curLat = img_data.latitude;
            double curLon = img_data.longitude;
            double imgHeight = img_data.m_LatitudeCountPerLongitudeLine;
            double imgWidth  = img_data.m_LongitudeProfileCount;

            int latIdx = (int) Math.round((curLat - minLat) / (maxLat - minLat) * (imgWidth - 1));
            int lonIdx = (int) Math.round((curLon - minLon) / (maxLon - minLon) * (imgHeight - 1));

            img_data.elevation = dtedDataRecord.getElevationPoint(m_Buff, lonIdx, latIdx);
            
            /**
            //Do not delete, this is a very useful debugging tool  for testing the accuracy and validity
            //of the file loader
            double maxElev = 0;
            int maxX = 0;
            int maxY = 0;
            for(int i=0; i<m_LongitudeProfileCount; i++)
                for(int j=0; j<m_LatitudeCountPerLongitudeLine; j++)
                    if( maxElev < dtedDataRecord.getElevationPoint(m_Buff, i,j)){
                        maxX = i;
                        maxY = j;
                        maxElev = dtedDataRecord.getElevationPoint(m_Buff, i, j);
                    }
            System.out.println("Max Point : " + maxElev + " at " + (1-maxY/((double)imgHeight)) + ", " + (maxX/((double)imgWidth)) );
            */

        } else {
            throw new IllegalArgumentException("Read_DTED_Data_Record FAILED to read DTED DATA RECORD SEGMENT");
        }

        return dtedDataRecord;
    }
}
