/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.math;

import elevationprofiler.Core;
import elevationprofiler.geographic.GeodeticDD;
import elevationprofiler.geographic.Vector;

/**
 *
 * @author ms6401
 */
public class GeoSLERP {
    
    public static GeodeticDD geoLERP(  GeodeticDD coordA, GeodeticDD coordB, double t ){
        
        GeodeticDD output = new GeodeticDD();
        output.lat = (coordB.lat - coordA.lat)*t + coordA.lat;
        output.lon = (coordB.lon - coordA.lon)*t + coordA.lon;
        return output;
    }
    
    public static GeodeticDD geoSLERP( GeodeticDD coordA, GeodeticDD coordB, double t ){
        
        //first convert the points into cartesian points
        Vector cartesianPointA = new Vector( coordA );
        Vector cartesianPointB = new Vector( coordB );
        
        
        //compute the cross product between the points
        Vector axis = Vector.cross(    cartesianPointA, cartesianPointB).norm();
        double angle= Vector.getAngle( cartesianPointA, cartesianPointB);
        
        
        //Create new Quaternions
        Quaternion mPoint = new Quaternion( 0, cartesianPointA );
        Quaternion q1 = new Quaternion().fromAxisAngle(  0  , axis);
        Quaternion q2 = new Quaternion().fromAxisAngle(angle, axis);
        
        
        // Calculate angle between them.
	double cosHalfTheta = Quaternion.dot(q1, q2);
        
        // if qa=qb or qa=-qb then theta = 0 and we can return qa
	if (Math.abs(cosHalfTheta) >= 1.0){
            return coordA;
	}
        
	// Calculate temporary values.
	double halfTheta = Math.acos(Quaternion.dot(q1, q2));
        double sinHalfTheta = Math.sin(halfTheta);
	
        // if theta = 180 degrees then result is not fully defined
	// we could rotate around any axis normal to qa or qb
	if (Math.abs(Math.sin(halfTheta)) < 0.001){ // fabs is floating point absolute
            return geoLERP(coordA, coordB, t);
	}
        if( Math.abs(Math.abs(halfTheta)-Math.PI) < 0.00000001 ){
            System.out.println("OTHERPOINT");
            GeodeticDD tcoordB = new GeodeticDD( coordB.lon-0.00001, coordB.lat-0.000001);
            return geoSLERP(coordA, tcoordB, t);
        }  
        
        
        //compute ratios
        Quaternion partA = Quaternion.mul( q1, Math.sin((1 - t) * halfTheta)/sinHalfTheta);
        Quaternion partB = Quaternion.mul( q2, Math.sin(   t    * halfTheta)/sinHalfTheta); 
	
        //calculate Quaternion.
	Quaternion qPart = Quaternion.mul(Quaternion.add( partA, partB), 1/sinHalfTheta);
        GeodeticDD output = Quaternion.mul(Quaternion.mul(qPart, new Quaternion( 0, cartesianPointA)), qPart.conj()).i.toGeodeticDD();
        
        return output;
    } 
}
