/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.math;

import elevationprofiler.geographic.Vector;

/**
 *
 * @author marvinsmith
 */
public class Quaternion {
    
    double w;
    Vector i;
    
    Quaternion(){
        w = 1;
        i = new Vector(0,0,0);
    }
    
    public Quaternion fromAxisAngle( double angle, Vector axis ){
        
        Quaternion out = new Quaternion();
        Vector nAxis = axis.norm();
        
        out.w = Math.cos(angle/2.0);
        if( out.w < 0.00001 ) out.w = 0;
        
        out.i.x = nAxis.x * Math.sin(angle/2.0);
        out.i.y = nAxis.y * Math.sin(angle/2.0);
        out.i.z = nAxis.z * Math.sin(angle/2.0);
        
        return out;
    }
    
    public Quaternion( double real, Vector imag ){
        i = imag;
        w = real;
    }
    
    
    public static double dot( Quaternion q1, Quaternion q2 ){
        return Math.sqrt( q1.w*q2.w + Vector.dot(q1.i, q2.i));
    }
    
    
    public static Quaternion add( Quaternion q1, Quaternion q2 ){
        return new Quaternion( q1.w+q2.w, Vector.add(q1.i,q2.i));
    }
    
    public static Quaternion mul( Quaternion q1, Quaternion q2 ){
        return new Quaternion( q1.w * q2.w - Vector.dot(q1.i, q2.i),
                               Vector.add( Vector.add(Vector.mul(q1.w,q2.i), Vector.mul(q2.w,q1.i)), Vector.cross(q1.i,q2.i))
                   );
    }
    
    
    public static Quaternion mul( Quaternion q, double val ){
        return new Quaternion( q.w*val, Vector.mul(q.i, val));
    }
    
    public Quaternion conj(){
        return new Quaternion(w, Vector.mul(i, -1));
    }
    
    public double mag2(){
        return w*w + i.x*i.x + i.y*i.y + i.z*i.z;//mag2();
    }
    
    public double mag(){
        return Math.sqrt(mag2());
    }
    
    public Vector getAxis(){
        
        double scale = i.mag();
        return new Vector(i.x/scale, i.y/scale, i.z/scale);
        
    }
    
    public Quaternion norm(){
        double sz = Math.sqrt( w*w + i.mag2());
        return new Quaternion( w/sz, new Vector(i.x/sz, i.y/sz, i.z/sz));
    }
    
    
    /**
     * Compute the angle of the Quaternion
     * 
     * @return Angle of the Quaternion 
     */
    public double getAngle(){
        return Math.acos(w)*2;
    }
    
    @Override
    public String toString(){
        return w + ", " + i;
    }
}
