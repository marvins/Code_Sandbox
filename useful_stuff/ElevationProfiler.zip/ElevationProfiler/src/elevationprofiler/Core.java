/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler;

import java.text.DecimalFormat;

/**
 *
 * @author ms6401
 */
public class Core {

    public static final double deg2rad = Math.PI / 180.0;
    public static final double rad2deg = 180.0 / Math.PI;
    
    public static final double deg2meters = 111699;

    public static double roundTwoDecimals(double value, int decimalPlaces) {

        String form = "#.";
        for( int i=0; i<decimalPlaces; i++){
            form += "#";
        }
        
        DecimalFormat twoDForm = new DecimalFormat(form);
        return Double.valueOf(twoDForm.format(value));
    }
}
