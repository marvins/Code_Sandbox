/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler;

import elevationprofiler.gui.MainGUI;
import javax.swing.JFrame;


/**
 *
 * @author ms6401
 */
public class ElevationProfiler {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MainGUI gui = new MainGUI();
        
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.pack();
        gui.setVisible(true);
        
    }
}
