/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.geographic;

/**
 *
 * @author ms6401
 */
public class GeodeticDD {
    
    public double lat;
    public double lon;
    
    
    public GeodeticDD(){
        lat = 0;
        lon = 0;
    }
    
    public GeodeticDD( double longitude, double latitude ){
        lat = latitude;
        lon = longitude;
    }
    
    public static boolean isEqual( GeodeticDD c1, GeodeticDD c2 ){
        
        double diff = Math.sqrt(
                                 Math.pow(Math.abs(c1.lat - c2.lat), 2)
                               + Math.pow(Math.abs(c1.lon - c2.lon), 2));
        
        if( diff < 0.0001 ){ 
            return true;
        }
        else{
            
            if(( Math.abs(c1.lat - 90) < 0.00001 && 
                 Math.abs(c2.lat - 90) < 0.00001 )||
               ( Math.abs(c1.lat + 90) < 0.00001 && 
                 Math.abs(c2.lat + 90) < 0.00001 )){
                
                return true;
            }
            else{
                return false;
            }
        }
    }


    @Override
    public String toString(){
        String output = "( " + String.format("%.4f", lat) + ", " + String.format("%.4f", lon) + " ) ";
        return output;
    }
    
    public String toKMLString(){
        String output = String.format("%.6f", lon) + "," + String.format("%.6f", lat);
        return output;
    }
}
