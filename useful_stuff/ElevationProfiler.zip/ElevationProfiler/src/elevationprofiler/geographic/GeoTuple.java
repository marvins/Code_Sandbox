/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.geographic;

/**
 *
 * @author ms6401
 */
public class GeoTuple {
    public GeodeticDD coordinate;
    public double elevationMeters;
    public double distanceStart = 0;
    
    public GeoTuple( ){
        coordinate = new GeodeticDD();
        elevationMeters = 0;
    }
    
    public GeoTuple( GeodeticDD coord ){
        coordinate = coord;
        elevationMeters = 0;
    }
    
    public GeoTuple( GeodeticDD coord, double height ){
        coordinate = coord;
        elevationMeters = height;
    }
    
    public GeoTuple( GeodeticDD coord, double height, double distance ){
        coordinate = coord;
        elevationMeters = height;
        distanceStart = distance;
    }
    
    public String toKMLString( ){
        
        String output = coordinate.toKMLString() + "," + elevationMeters;
        return output;
    }
}
