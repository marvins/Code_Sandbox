/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.geographic;

import elevationprofiler.Core;

/**
 *
 * @author ms6401
 */
public class Vincenty {
    
    private static final double deg2rad = Math.PI/180.0;
    private static final double rad2deg = 180.0/Math.PI;
    
    public static double distanceMeters( GeodeticDD coordinateA, GeodeticDD coordinateB ){
        
        //if coordinates have the same latitude, then we need to use a different method
        if( Math.abs(coordinateA.lat - coordinateB.lat) < 0.00001 ){
            return distanceFormula( coordinateA, coordinateB );
        }
        
        double output = 0;
        
        //assuming WGS84, use standard ellipsoid parameters
        double a = 6378137;
        double b = 6356752.314245;
        double f = 1/298.257223563;  // WGS-84 ellipsiod
        
        //latitudes
        double latA = coordinateA.lat * deg2rad;
        double latB = coordinateB.lat * deg2rad;
        
        //longitude difference
        double L = (coordinateB.lon - coordinateA.lon)*deg2rad;
        
        double U1 = Math.atan((1-f)*Math.tan(latA));
        double U2 = Math.atan((1-f)*Math.tan(latB));
        
        double sinU1 = Math.sin(U1); double cosU1 = Math.cos(U1);
        double sinU2 = Math.sin(U2); double cosU2 = Math.cos(U2);
        
        double lambda = L; //first approximation
        double lambda2;
        double deltaL = 100000;
        int iterations = 0;
        
        double sinLambda, cosLambda, sinSigma = 0, cosSigma = 0, sigma = 0, sinAlpha, cos2alpha = 0, cos2sigmaM = 0, C;
        double tempA, tempB, tempC;
        
        //useful variables 
        double a2 = Math.pow(a, 2);
        double b2 = Math.pow(b, 2);
        
        while( iterations < 1 || ( iterations < 12 && deltaL > 1E-12 /*0.000000001*/ ) ){
            
            //small variables, big space and computation savings
            sinLambda = Math.sin(lambda);
            cosLambda = Math.cos(lambda);
            
            tempA = ( cosU2 * sinLambda ) * ( cosU2 * sinLambda );
            tempB = ( cosU1 * sinU2 - sinU1 * cosU2 * cosLambda );
            sinSigma = Math.sqrt( tempA + tempB * tempB );
                
            cosSigma = sinU1*sinU2 + cosU1*cosU2*cosLambda;
            
            sigma = Math.atan2( sinSigma, cosSigma);
            
            sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma;
            
            cos2alpha = 1 - sinAlpha*sinAlpha;
            
            cos2sigmaM = cosSigma - 2 * sinU1 * sinU2/cos2alpha;
            
            C = f / 16*cos2alpha*(4 + f *(4 - 3 * cos2alpha));
            
            
            tempA = -1 + 2 * cos2sigmaM * cos2sigmaM;
            tempB = cos2sigmaM + C*cosSigma*tempA;
            tempC = sigma + C * sinSigma * tempB;
            lambda2 = L + (1-C) * f * sinAlpha * tempC;
            
            deltaL = Math.abs( lambda- lambda2);
            
            
            
            iterations++;
            lambda = lambda2;
        }
        
        double u2 = cos2alpha * (a2 - b2)/b2;
              
        double A = 1 + u2 / 16384 * ( 4096 + u2 * ( -768 + u2*(320 - 175 *u2)));
        double B = u2 /  1024 * ( 256 + u2 * ( -128 + u2 * ( 74 - 47*u2)));
        
        tempB = (cosSigma*(-1+2*cos2sigmaM*cos2sigmaM)- B/6*cos2sigmaM*(-3+4*sinSigma*sinSigma)*(-3+4*cos2sigmaM*cos2sigmaM));
        tempC = (cos2sigmaM + B/4*tempB);
        double dSigma = B*sinSigma*tempC;        
        
        output = b*A*(sigma - dSigma );
        
        return output;
    }
    
    public static double distanceFormula( GeodeticDD coordA, GeodeticDD coordB ){
        
        double output = Math.sqrt( Math.pow(coordA.lat - coordB.lat, 2) + Math.pow(coordA.lon - coordB.lon, 2))*Core.deg2meters;
        
        return output;
    }
    
}
