/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.geographic;

import elevationprofiler.dted.DTEDLoader;
import elevationprofiler.io.ConfigurationManager;
import elevationprofiler.io.KMLParser;
import elevationprofiler.math.GeoSLERP;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 *
 * @author ms6401
 */
public class RouteContainer {
    
    public String kml_filename = "None Loaded";
    public ArrayList<GeodeticDD> coordinateList = null;
    public boolean valid = false;
    
    public double distance;
    
    public void buildRoute( String filename ){
           
        try{
            KMLParser psr = new KMLParser();
            coordinateList = psr.openKMLFile(filename);
        }
        catch( Exception e ){
            System.out.println("ERROR: " + e.getMessage());
        }
        if( coordinateList.size() <= 0 ) {
            kml_filename = "ERROR: Invalid File";
        }
        else{
            kml_filename = filename;
            valid = true;
        }
        
        //find the full distance
        distance = 0;
        for( int i=0; i<coordinateList.size()-1; i++) {
            distance += Vincenty.distanceMeters(coordinateList.get(i), coordinateList.get(i+1));
        }
        
        
    }
    
    
    public ArrayList<GeoTuple> computeProfile( int step_count, ConfigurationManager options ) throws FileNotFoundException{
        
        //create output container
        ArrayList<GeoTuple> output = new ArrayList<>();
        
        //for each adjacent pair, we need the distance between points / total distance
        int midCnt;
        double ratio, qratio;
        GeoTuple tempTuple = new GeoTuple();
        
        //iterate over each element
        for( int i=0; i<coordinateList.size()-1; i++ ){
            
            output.add(new GeoTuple(coordinateList.get(i), DTEDLoader.point2ElevationMeters(coordinateList.get(i), options.dted_root_location)));
            
            //compute the number of points we need in between waypoints
            ratio = Vincenty.distanceMeters(coordinateList.get(i), coordinateList.get(i+1)) / distance;
            midCnt = (int)(ratio*step_count);
            
            //iterate over each required step
            for( int j=0; j<midCnt-1; j++ ){
                
                //compute the ratio
                qratio = (double)j/midCnt;
                
                //use SLERP to get the intermediate point
                GeodeticDD coordinate = GeoSLERP.geoSLERP( coordinateList.get(i), coordinateList.get(i+1), qratio);
                output.add(new GeoTuple(coordinate, DTEDLoader.point2ElevationMeters(coordinate, options.dted_root_location)));
                
            }
        }
        output.add(new GeoTuple(coordinateList.get(coordinateList.size()-1), DTEDLoader.point2ElevationMeters(coordinateList.get(coordinateList.size()-1), options.dted_root_location)));
        
        
        output.set( 0, new GeoTuple( output.get(0).coordinate, output.get(0).elevationMeters, 0));
        double dist = 0;
        for( int i=1; i<output.size(); i++){
            dist += Vincenty.distanceMeters(output.get(i-1).coordinate, output.get(i).coordinate);
            
            output.set( i, new GeoTuple( output.get(i).coordinate, output.get(i).elevationMeters, dist));
        }
        
        
        return output;
    }
    
    
    
}
