/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.geographic;

import elevationprofiler.Core;

/**
 *
 * @author marvinsmith
 */
public class Vector {
    
    public double x;
    public double y;
    public double z;
    
    public Vector(){
        x = 0;
        y = 0;
        z = 0;
    }
    
    public Vector( Vector in ){
        x = in.x;
        y = in.y;
        z = in.z;
    }
    
    public Vector( double X, double Y, double Z ){
        x = X;
        y = Y;
        z = Z;
    }
    
    public Vector( GeodeticDD point ){
        
        x = Math.cos(point.lat*Core.deg2rad)*Math.cos(point.lon*Core.deg2rad);
        y = Math.cos(point.lat*Core.deg2rad)*Math.sin(point.lon*Core.deg2rad);
        z = Math.sin(point.lat*Core.deg2rad);
        
    }
    
    public GeodeticDD toGeodeticDD( ){
        return new GeodeticDD( Math.atan2(y,x)*Core.rad2deg, Math.asin(z/mag())*Core.rad2deg);
    }
    
    public static double dot( Vector a, Vector b){
        return ( a.x*b.x + a.y*b.y + a.z*b.z);
    }
    
    public double mag2(){
        return x*x+y*y+z*z;
    }
    
    public double mag(){
        return Math.sqrt(mag2());
    }
    
    public static Vector norm( Vector vec ){
        double mag = vec.mag();
        
        return Vector.mul(vec, 1/mag);
    }
    
    public static Vector add( Vector v1, Vector v2 ){
        return new Vector( v1.x+v2.x, v1.y+v2.y, v1.z+v2.z);
    }
    
    public static Vector mul( double scalar, Vector vec ){
        return mul( vec,scalar);
    }
    
    public static Vector mul( Vector vec, double scalar ){
        Vector output = new Vector( vec.x*scalar, vec.y*scalar, vec.z*scalar );
        if( Math.abs(output.x) < 0.00001 ){ output.x = 0; }
        if( Math.abs(output.y) < 0.00001 ){ output.y = 0; }
        if( Math.abs(output.z) < 0.00001 ){ output.z = 0; }
        
        return output;
    }

    public static Vector cross( Vector vA, Vector vB ){
        
        return new Vector( vA.y*vB.z - vA.z*vB.y, 
                           vA.z*vB.x - vA.x*vB.z,
                           vA.x*vB.y - vA.y*vB.x);
    }
    
    
    public Vector norm(){
        
        double val = mag();
        return new Vector( x/val, y/val, z/val);
    }
    
    public static double getAngle( Vector vA, Vector vB ){
        return Math.acos( Vector.dot( vA.norm(), vB.norm())/ vA.mag()*vB.mag());
    }
    
    @Override
    public String toString(){
        return "( " + x + ", " + y + ", " + z + " )";
    }
}