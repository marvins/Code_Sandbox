/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.dted;

import elevationprofiler.geographic.GeodeticDD;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ms6401
 */
public class DTEDLoaderTest {
    
    /**
     * Test of coordinate2ElevationMeters method, of class DTEDLoader.
     */
    @Test
    public void testCoordinate2ElevationMeters() {
        System.out.println("coordinate2ElevationMeters");
        
        GeodeticDD coordinate = new GeodeticDD( -117.8, 36.1);
        
        String root_dir;
        root_dir = "C:\\Users\\ms6401\\Desktop\\linux_share\\dted_data\\data";
        
        double expResult = 0.0;
        double result = DTEDLoader.point2ElevationMeters(coordinate, root_dir);
        assertEquals(expResult, result, 0.0);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}
