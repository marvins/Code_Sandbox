/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package elevationprofiler.math;

import elevationprofiler.geographic.GeodeticDD;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ms6401
 */
public class GeoSLERPTest {
    
    /**
     * Test of geoLERP method, of class GeoSLERP
     */
    @Test
    public void testGeoLERP(){
        
        System.out.println("geoLERP");
        GeodeticDD coordA = new GeodeticDD(  0,  0);
        GeodeticDD coordB = new GeodeticDD(  1,  1);
        GeodeticDD coordC = new GeodeticDD( -1, -1);
        
        GeodeticDD result01 = GeoSLERP.geoLERP(coordA, coordB, 0.5);
        GeodeticDD result02 = GeoSLERP.geoLERP(coordA, coordC, 0.5);
        GeodeticDD result03 = GeoSLERP.geoLERP(coordB, coordC, 0.5);
        
        assertEquals( true, GeodeticDD.isEqual(result01, result01));
        assertEquals( true, GeodeticDD.isEqual(result02, result02));
        assertEquals( true, GeodeticDD.isEqual(coordA, result03));
        
    }
    
    
    /**
     * Test of geoSLERP method, of class GeoSLERP.
     */
    @Test
    public void testGeoSLERP() {
        System.out.println("geoSLERP");
        GeodeticDD coordA = new GeodeticDD(  0,  0);
        GeodeticDD coordB = new GeodeticDD( 90, 90);
        GeodeticDD coordC = new GeodeticDD(-90,-90);
        GeodeticDD coordD = new GeodeticDD( 90, 0);
        GeodeticDD coordE = new GeodeticDD(  0,90);
        
        GeodeticDD result01 = GeoSLERP.geoSLERP(coordA, coordB, 0);
        GeodeticDD result02 = GeoSLERP.geoSLERP(coordA, coordB, 1);
        GeodeticDD result03 = GeoSLERP.geoSLERP(coordB, coordA, 0);
        GeodeticDD result04 = GeoSLERP.geoSLERP(coordB, coordA, 1);
        
        GeodeticDD result11 = GeoSLERP.geoSLERP(coordA, coordC, 0);
        GeodeticDD result12 = GeoSLERP.geoSLERP(coordA, coordC, 1);
        GeodeticDD result13 = GeoSLERP.geoSLERP(coordC, coordA, 0);
        GeodeticDD result14 = GeoSLERP.geoSLERP(coordC, coordA, 1);
        
        //run some checks
        assertEquals( true, GeodeticDD.isEqual(result01, coordA));
        assertEquals( true, GeodeticDD.isEqual(result02, coordB));
        assertEquals( true, GeodeticDD.isEqual(result03, coordB));
        assertEquals( true, GeodeticDD.isEqual(result04, coordA));
        assertEquals( true, GeodeticDD.isEqual(result11, coordA));
        assertEquals( true, GeodeticDD.isEqual(result12, coordC));
        assertEquals( true, GeodeticDD.isEqual(result13, coordC));
        assertEquals( true, GeodeticDD.isEqual(result14, coordA));
        
        
        
    }
}
